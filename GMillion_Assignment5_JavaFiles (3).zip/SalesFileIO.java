import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/*
 * Class: CMSC203
 * Instructor: Huseyin Aygun
 * Description: This class reads sales numbers from a file into a ragged 2D array and writes a summary file.
 * Due: 11/16/2026
 * Platform/compiler: Java, Eclipse
 * I pledge that I have completed the programming
 * assignment independently. I have not copied the code
 * from a student or any source. I have not given my code
 * to any student.
   Print your Name here: Gabriela Million
*/

public class SalesFileIO {

    /**
     * Reads the sales file into a ragged 2D array.
     * Each line is one row. I read the file two times:
     * the first time counts the lines, the second time gets the numbers.
     */
    public static double[][] readSalesData(String filename) throws FileNotFoundException {
        File file = new File(filename);

        // first time through: count the lines that are not empty
        Scanner counter = new Scanner(file);
        int lineCount = 0;
        while (counter.hasNextLine()) {
            String line = counter.nextLine().trim();
            if (!line.equals("")) {
                lineCount++;
            }
        }
        counter.close();

        // make the array with one row for each line
        double[][] data = new double[lineCount][];

        // second time through: fill in the numbers
        Scanner reader = new Scanner(file);
        int row = 0;
        while (reader.hasNextLine()) {
            String line = reader.nextLine().trim();
            if (!line.equals("")) {
                // split the line at the spaces
                String[] pieces = line.split(" ");
                data[row] = new double[pieces.length];
                for (int c = 0; c < pieces.length; c++) {
                    data[row][c] = Double.parseDouble(pieces[c]);
                }
                row++;
            }
        }
        reader.close();

        return data;
    }

    /**
     * Writes the summary to a file.
     * It has the totals, highest and lowest, and my name at the end.
     */
    public static void writeSummary(String filename, double[][] data) throws IOException {
        PrintWriter writer = new PrintWriter(filename);

        writer.printf("Total sales: %.2f%n", SalesDataUtility.getTotal(data));
        writer.printf("Average sale: %.2f%n", SalesDataUtility.getAverage(data));
        writer.printf("Highest sale: %.2f%n", SalesDataUtility.getHighestInArray(data));
        writer.printf("Lowest sale: %.2f%n", SalesDataUtility.getLowestInArray(data));
        writer.println();

        // info for each row
        for (int r = 0; r < data.length; r++) {
            writer.printf("Row %d total: %.2f%n", r, SalesDataUtility.getRowTotal(data, r));
            writer.printf("Row %d highest: %.2f%n", r, SalesDataUtility.getHighestInRow(data, r));
            writer.printf("Row %d lowest: %.2f%n", r, SalesDataUtility.getLowestInRow(data, r));
        }
        writer.println();

        // find the longest row so we know how many columns there are
        int mostColumns = 0;
        for (int r = 0; r < data.length; r++) {
            if (data[r].length > mostColumns) {
                mostColumns = data[r].length;
            }
        }

        // total for each column
        for (int c = 0; c < mostColumns; c++) {
            writer.printf("Column %d total: %.2f%n", c, SalesDataUtility.getColumnTotal(data, c));
        }
        writer.println();

        writer.println("Programmer: Gabriela Million");
        writer.close();
    }
}
