import static org.junit.Assert.*;
import org.junit.Test;

/*
 * Class: CMSC203
 * Instructor: Huseyin Aygun
 * Description: JUnit tests for the SalesDataUtility methods using a ragged array.
 * Due: 11/16/2026
 * Platform/compiler: Java, Eclipse
 * I pledge that I have completed the programming
 * assignment independently. I have not copied the code
 * from a student or any source. I have not given my code
 * to any student.
   Print your Name here: Gabriela Million
*/

public class SalesDataUtilityJUnitStudentTest {

    // ragged array: rows have 3, 2, and 4 numbers
    private double[][] data = {
        {100.50, 200.75, 150.00},
        {80.00, 90.00},
        {220.10, 130.50, 300.00, 50.25}
    };

    // checks the total of all 9 numbers
    @Test
    public void testGetTotal() {
        assertEquals(1322.10, SalesDataUtility.getTotal(data), 0.001);
    }

    // checks the average (1322.10 / 9)
    @Test
    public void testGetAverage() {
        assertEquals(146.90, SalesDataUtility.getAverage(data), 0.001);
    }

    // checks the total of each row
    @Test
    public void testGetRowTotal() {
        assertEquals(451.25, SalesDataUtility.getRowTotal(data, 0), 0.001);
        assertEquals(170.00, SalesDataUtility.getRowTotal(data, 1), 0.001);
        assertEquals(700.85, SalesDataUtility.getRowTotal(data, 2), 0.001);
    }

    // checks the total of each column (short rows get skipped)
    @Test
    public void testGetColumnTotal() {
        assertEquals(400.60, SalesDataUtility.getColumnTotal(data, 0), 0.001);
        assertEquals(421.25, SalesDataUtility.getColumnTotal(data, 1), 0.001);
        assertEquals(450.00, SalesDataUtility.getColumnTotal(data, 2), 0.001);
        assertEquals(50.25, SalesDataUtility.getColumnTotal(data, 3), 0.001);
    }

    // checks the highest and lowest in each row
    @Test
    public void testHighestLowestInRow() {
        assertEquals(200.75, SalesDataUtility.getHighestInRow(data, 0), 0.001);
        assertEquals(100.50, SalesDataUtility.getLowestInRow(data, 0), 0.001);
        assertEquals(90.00, SalesDataUtility.getHighestInRow(data, 1), 0.001);
        assertEquals(80.00, SalesDataUtility.getLowestInRow(data, 1), 0.001);
        assertEquals(300.00, SalesDataUtility.getHighestInRow(data, 2), 0.001);
        assertEquals(50.25, SalesDataUtility.getLowestInRow(data, 2), 0.001);
    }

    // checks the highest and lowest in the whole array
    @Test
    public void testHighestLowestInArray() {
        assertEquals(300.00, SalesDataUtility.getHighestInArray(data), 0.001);
        assertEquals(50.25, SalesDataUtility.getLowestInArray(data), 0.001);
    }
}
