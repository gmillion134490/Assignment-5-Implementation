import static org.junit.Assert.*;
import org.junit.Test;

/*
 * Class: CMSC203
 * Instructor: Huseyin Aygun
 * Description: JUnit tests for the SalesDataUtility methods. The test
 *              array is ragged (rows have different lengths).
 * Due: 11/16/2026
 * Platform/compiler: Java, Eclipse
 * I pledge that I have completed the programming
 * assignment independently. I have not copied the code
 * from a student or any source. I have not given my code
 * to any student.
   Print your Name here: Gabriela Million
*/

public class SalesDataUtilityJUnitStudentTest {

    // ragged array with 3 rows: 3 numbers, 2 numbers, and 4 numbers
    private double[][] data = {
        {100.50, 200.75, 150.00},
        {80.00, 90.00},
        {220.10, 130.50, 300.00, 50.25}
    };

    // tests getTotal (all 9 numbers added up)
    @Test
    public void testGetTotal() {
        assertEquals(1322.10, SalesDataUtility.getTotal(data), 0.001);
    }

    // tests getAverage (1322.10 divided by 9 numbers)
    @Test
    public void testGetAverage() {
        assertEquals(146.90, SalesDataUtility.getAverage(data), 0.001);
    }

    // tests getRowTotal for each of the 3 rows
    @Test
    public void testGetRowTotal() {
        assertEquals(451.25, SalesDataUtility.getRowTotal(data, 0), 0.001);
        assertEquals(170.00, SalesDataUtility.getRowTotal(data, 1), 0.001);
        assertEquals(700.85, SalesDataUtility.getRowTotal(data, 2), 0.001);
    }

    // tests getColumnTotal, row 1 is too short for columns 2 and 3
    // and row 0 is too short for column 3
    @Test
    public void testGetColumnTotal() {
        assertEquals(400.60, SalesDataUtility.getColumnTotal(data, 0), 0.001);
        assertEquals(421.25, SalesDataUtility.getColumnTotal(data, 1), 0.001);
        assertEquals(450.00, SalesDataUtility.getColumnTotal(data, 2), 0.001);
        assertEquals(50.25, SalesDataUtility.getColumnTotal(data, 3), 0.001);
    }

    // tests getHighestInRow and getLowestInRow
    @Test
    public void testHighestLowestInRow() {
        assertEquals(200.75, SalesDataUtility.getHighestInRow(data, 0), 0.001);
        assertEquals(100.50, SalesDataUtility.getLowestInRow(data, 0), 0.001);
        assertEquals(90.00, SalesDataUtility.getHighestInRow(data, 1), 0.001);
        assertEquals(80.00, SalesDataUtility.getLowestInRow(data, 1), 0.001);
        assertEquals(300.00, SalesDataUtility.getHighestInRow(data, 2), 0.001);
        assertEquals(50.25, SalesDataUtility.getLowestInRow(data, 2), 0.001);
    }

    // tests getHighestInArray and getLowestInArray
    @Test
    public void testHighestLowestInArray() {
        assertEquals(300.00, SalesDataUtility.getHighestInArray(data), 0.001);
        assertEquals(50.25, SalesDataUtility.getLowestInArray(data), 0.001);
    }
}
