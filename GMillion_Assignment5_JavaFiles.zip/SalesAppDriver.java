import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/*
 * Class: CMSC203
 * Instructor: Huseyin Aygun
 * Description: This is the console driver. It asks for the input and output
 *              file names, reads the sales data, shows the results, and
 *              saves a summary file.
 * Due: 11/16/2026
 * Platform/compiler: Java, Eclipse
 * I pledge that I have completed the programming
 * assignment independently. I have not copied the code
 * from a student or any source. I have not given my code
 * to any student.
   Print your Name here: Gabriela Million
*/

public class SalesAppDriver {

    /**
     * Main method. Asks the user for file names, reads the data, prints the
     * results on the screen, and writes the summary file. If something goes
     * wrong (bad file or bad number) it prints a message instead of crashing.
     */
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        System.out.print("Enter the input file name: ");
        String inputFile = keyboard.nextLine();
        System.out.print("Enter the output file name: ");
        String outputFile = keyboard.nextLine();

        try {
            // read the file
            double[][] data = SalesFileIO.readSalesData(inputFile);

            if (data.length == 0) {
                System.out.println("The file has no data in it.");
            } else {
                // show the results
                System.out.println();
                System.out.printf("Total sales: %.2f%n", SalesDataUtility.getTotal(data));
                System.out.printf("Average sale: %.2f%n", SalesDataUtility.getAverage(data));
                System.out.printf("Highest sale: %.2f%n", SalesDataUtility.getHighestInArray(data));
                System.out.printf("Lowest sale: %.2f%n", SalesDataUtility.getLowestInArray(data));

                for (int r = 0; r < data.length; r++) {
                    System.out.printf("Row %d total: %.2f%n", r, SalesDataUtility.getRowTotal(data, r));
                }

                // save the summary file
                SalesFileIO.writeSummary(outputFile, data);
                System.out.println();
                System.out.println("Summary was saved to " + outputFile);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: the file " + inputFile + " was not found.");
        } catch (NumberFormatException e) {
            System.out.println("Error: the file has something that is not a number.");
        } catch (IOException e) {
            System.out.println("Error: could not write the output file.");
        }

        keyboard.close();

        // print my name at the end
        System.out.println();
        System.out.println("Programmer: Gabriela Million");
    }
}
