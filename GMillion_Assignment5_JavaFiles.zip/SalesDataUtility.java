/*
 * Class: CMSC203
 * Instructor: Huseyin Aygun
 * Description: This class has static methods that do math on a ragged
 *              2D array of sales numbers (totals, averages, highest, lowest).
 * Due: 11/16/2026
 * Platform/compiler: Java, Eclipse
 * I pledge that I have completed the programming
 * assignment independently. I have not copied the code
 * from a student or any source. I have not given my code
 * to any student.
   Print your Name here: Gabriela Million
*/

public class SalesDataUtility {

    /**
     * Adds up every number in the whole array and returns the total.
     * It uses a loop inside a loop to go through each row and each column.
     */
    public static double getTotal(double[][] data) {
        double total = 0;
        for (int r = 0; r < data.length; r++) {
            for (int c = 0; c < data[r].length; c++) {
                total = total + data[r][c];
            }
        }
        return total;
    }

    /**
     * Finds the average of all the numbers in the array.
     * It adds them up and divides by how many numbers there are.
     * If there are no numbers it returns 0 so we do not divide by zero.
     */
    public static double getAverage(double[][] data) {
        double total = 0;
        int count = 0;
        for (int r = 0; r < data.length; r++) {
            for (int c = 0; c < data[r].length; c++) {
                total = total + data[r][c];
                count++;
            }
        }
        if (count == 0) {
            return 0;
        }
        return total / count;
    }

    /**
     * Adds up all the numbers in one row (one department).
     * The row number is given to the method.
     */
    public static double getRowTotal(double[][] data, int row) {
        double total = 0;
        for (int c = 0; c < data[row].length; c++) {
            total = total + data[row][c];
        }
        return total;
    }

    /**
     * Adds up all the numbers in one column.
     * Some rows are shorter than the column number, so we skip those rows.
     */
    public static double getColumnTotal(double[][] data, int col) {
        double total = 0;
        for (int r = 0; r < data.length; r++) {
            // only add if this row is long enough to have this column
            if (col < data[r].length) {
                total = total + data[r][col];
            }
        }
        return total;
    }

    /**
     * Finds the biggest number in one row.
     * We start with the first number and check the rest.
     */
    public static double getHighestInRow(double[][] data, int row) {
        double highest = data[row][0];
        for (int c = 1; c < data[row].length; c++) {
            if (data[row][c] > highest) {
                highest = data[row][c];
            }
        }
        return highest;
    }

    /**
     * Finds the smallest number in one row.
     * We start with the first number and check the rest.
     */
    public static double getLowestInRow(double[][] data, int row) {
        double lowest = data[row][0];
        for (int c = 1; c < data[row].length; c++) {
            if (data[row][c] < lowest) {
                lowest = data[row][c];
            }
        }
        return lowest;
    }

    /**
     * Finds the biggest number in the whole array.
     * It checks every row and every column.
     */
    public static double getHighestInArray(double[][] data) {
        double highest = data[0][0];
        for (int r = 0; r < data.length; r++) {
            for (int c = 0; c < data[r].length; c++) {
                if (data[r][c] > highest) {
                    highest = data[r][c];
                }
            }
        }
        return highest;
    }

    /**
     * Finds the smallest number in the whole array.
     * It checks every row and every column.
     */
    public static double getLowestInArray(double[][] data) {
        double lowest = data[0][0];
        for (int r = 0; r < data.length; r++) {
            for (int c = 0; c < data[r].length; c++) {
                if (data[r][c] < lowest) {
                    lowest = data[r][c];
                }
            }
        }
        return lowest;
    }
}
