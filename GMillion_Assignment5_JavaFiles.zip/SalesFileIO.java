import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * Class: CMSC203
 * Instructor: Huseyin Aygun
 * Description: This class reads the sales numbers from a text file into a
 *              ragged 2D array and writes a summary to an output file.
 * Due: 11/16/2026
 * Platform/compiler: Java, Eclipse
 * I pledge that I have completed the programming
 * assignment independently. I have not copied the code
 * from a student or any source. I have not given my code
 * to any student.
   Print your Name here: Gabriela Million
*/

public class SalesFileIO {

    /**
     * Reads the file one line at a time. Each line is one department.
     * The numbers on a line are split by spaces and changed into doubles.
     * Every row can be a different length (ragged array).
     * If the file is not found it throws FileNotFoundException.
     * If a word is not a number it throws NumberFormatException.
     */
    public static double[][] readSalesData(String filename) throws FileNotFoundException {
        File file = new File(filename);
        Scanner fileScanner = new Scanner(file);

        // first put all the lines in a list (skip empty lines)
        ArrayList<String> lines = new ArrayList<String>();
        while (fileScanner.hasNextLine()) {
            String line = fileScanner.nextLine().trim();
            if (!line.equals("")) {
                lines.add(line);
            }
        }
        fileScanner.close();

        // make the array with one row for each line
        double[][] data = new double[lines.size()][];

        // fill each row
        for (int r = 0; r < lines.size(); r++) {
            String[] pieces = lines.get(r).split(" ");
            data[r] = new double[pieces.length];
            for (int c = 0; c < pieces.length; c++) {
                data[r][c] = Double.parseDouble(pieces[c]);
            }
        }
        return data;
    }

    /**
     * Writes the summary to a file. It writes the total, average, highest,
     * lowest, the row totals, the highest and lowest of each row, and the
     * column totals. The last line is the programmer's name.
     */
    public static void writeSummary(String filename, double[][] data) throws IOException {
        PrintWriter writer = new PrintWriter(filename);

        writer.printf("Total sales: %.2f%n", SalesDataUtility.getTotal(data));
        writer.printf("Average sale: %.2f%n", SalesDataUtility.getAverage(data));
        writer.printf("Highest sale: %.2f%n", SalesDataUtility.getHighestInArray(data));
        writer.printf("Lowest sale: %.2f%n", SalesDataUtility.getLowestInArray(data));
        writer.println();

        // one set of lines for each row
        for (int r = 0; r < data.length; r++) {
            writer.printf("Row %d total: %.2f%n", r, SalesDataUtility.getRowTotal(data, r));
            writer.printf("Row %d highest: %.2f%n", r, SalesDataUtility.getHighestInRow(data, r));
            writer.printf("Row %d lowest: %.2f%n", r, SalesDataUtility.getLowestInRow(data, r));
        }
        writer.println();

        // find the longest row so we know how many columns there are
        int mostColumns = 0;
        for (int r = 0; r < data.length; r++) {
            if (data[r].length > mostColumns) {
                mostColumns = data[r].length;
            }
        }

        // one line for each column
        for (int c = 0; c < mostColumns; c++) {
            writer.printf("Column %d total: %.2f%n", c, SalesDataUtility.getColumnTotal(data, c));
        }
        writer.println();

        writer.println("Programmer: Gabriela Million");
        writer.close();
    }
}
